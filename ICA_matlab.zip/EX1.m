% example 
sig1=0.5*sin([1:0.05:30]);
sig1=sig1./std(sig1);
sig2=rand(size(sig1))-0.5;
sig2=sig2./std(sig2);
figure; % visuliza those 4 siginals
subplot(2,1,1)
plot(sig1)
subplot(2,1,2)
plot(sig2)

A=[1,5;0.3,2];
mixedsig=A*[sig1;sig2]; % generate three normal signal with 300 observations each
figure; % visuliza those 4 siginals
for i=1:2
subplot(2,1,i)
plot(mixedsig(i,:))
end

figure
for i=1:2
subplot(2,1,i)
hist(mixedsig(i,:))
end


[icasig A W] = FASTICA (mixedsig); % find the ICs by default setting
figure; % visuliza those 4 siginals
for i=1:2
subplot(2,1,i)
plot(icasig(i,:))
end

figure; % visuliza those 4 siginals
for i=1:2
subplot(2,1,i)
hist(icasig(i,:))
end



% W=rand(10,2);
% W_new=W*real(sqrtm(inv(W'*W)));





