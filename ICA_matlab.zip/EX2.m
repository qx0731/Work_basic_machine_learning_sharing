% read in source 
I = imread('p1.png');
J = (rgb2gray(I));
figure;
imshow(I)
J_final(1,:)=im2double(reshape(J(1:200,1:200),1,40000));
J_final(1,:)=J_final(1,:)./std(J_final(1,:));

I = imread('p2.png');
J = (rgb2gray(I));
figure;
imshow(I)
J_final(2,:)=reshape(J(1:200,1:200),1,40000);
J_final(2,:)=J_final(2,:)./std(J_final(2,:));
figure
for i=1:2
subplot(2,1,i)
imshow(reshape(J_final(i,:),200,200))
end


% generate mixed
A= [ 0.2186    0.2830;
    0.0119    0.3113];
mixedsig=A*(J_final);
figure
for i=1:2
subplot(2,1,i)
imshow((reshape(mixedsig(i,:),200,200)))
end
[icasig A1 W] = FASTICA (mixedsig);

figure
for i=1:2
subplot(2,1,i)
imshow((reshape(icasig(i,:),200,200)))
end

index=[-1,1];
figure
for i=1:2
subplot(2,1,i)
imshow((reshape(index(i)*icasig(i,:),200,200)))
end

index=[1,-1];
figure
for i=1:2
subplot(2,1,i)
imshow((reshape(index(i)*icasig(i,:),200,200)))
end
index=[-1,-1];
figure
for i=1:2
subplot(2,1,i)
imshow((reshape(index(i)*icasig(i,:),200,200)))
end


%% Four observation 
A= [ 0.2186    0.2830;
    0.0119    0.3113;
     0.2638    0.1361;
    0.1455    0.8693];
mixedsig=A*(J_final);
figure
for i=1:4
subplot(2,2,i)
imshow((reshape(mixedsig(i,:),200,200)))
end
[icasig A1 W] = FASTICA (mixedsig);

figure
for i=1:2
subplot(2,1,i)
imshow((reshape(icasig(i,:),200,200)))
end

index=[-1,1];
figure
for i=1:2
subplot(2,1,i)
imshow((reshape(index(i)*icasig(i,:),200,200)))
end

index=[1,-1];
figure
for i=1:2
subplot(2,1,i)
imshow((reshape(index(i)*icasig(i,:),200,200)))
end
index=[-1,-1];
figure
for i=1:2
subplot(2,1,i)
imshow((reshape(index(i)*icasig(i,:),200,200)))
end